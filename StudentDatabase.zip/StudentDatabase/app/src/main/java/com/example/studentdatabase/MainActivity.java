package com.example.studentdatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String studentID = null;
    private String grade = null;
    private String firstName = null;
    private String lastName = null;

    private EditText enterIDEditText, enterFirstNameEditText, enterLastNameEditText, enterGradeEditText;
    private DBHandler dbHandler;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enterIDEditText = findViewById(R.id.enterIDEditText);
        enterFirstNameEditText = findViewById(R.id.enterFirstNameEditText);
        enterLastNameEditText = findViewById(R.id.enterLastNameEditText);
        enterGradeEditText =  findViewById(R.id.enterGradeEditText);
        Button addButton = findViewById(R.id.addButton);
        Button viewButton = findViewById(R.id.viewButton);

        dbHandler = new DBHandler(MainActivity.this);

        addButton.setOnClickListener(v -> {
            try{
                studentID = enterIDEditText.getText().toString();
                firstName = enterFirstNameEditText.getText().toString();
                lastName = enterLastNameEditText.getText().toString();
                grade = enterGradeEditText.getText().toString();

                if (studentID.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Student ID is Mandatory",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                else if (!dbHandler.checkStudentID(studentID)){
                    Toast.makeText(MainActivity.this, "Student ID is a Duplicate",
                            Toast.LENGTH_SHORT).show();
                }
                else{
                    dbHandler.addNewStudent(studentID, firstName, lastName, grade);
                }
            }
            catch (Exception e){
                Toast.makeText(MainActivity.this, "Something went wrong; try again.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(MainActivity.this, "Student Record Added",
                    Toast.LENGTH_SHORT).show();
            enterIDEditText.setText("");
            enterFirstNameEditText.setText("");
            enterLastNameEditText.setText("");
            enterGradeEditText.setText("");
        });

        viewButton.setOnClickListener(v -> {
            try {
                Intent i = new Intent(MainActivity.this, ViewStudents.class);
                startActivity(i);
            }
            catch (Exception e){
                Toast.makeText(MainActivity.this, "Something went wrong; try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}