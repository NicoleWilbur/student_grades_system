package com.example.studentdatabase;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StudentViewer extends RecyclerView.Adapter<StudentViewer.ViewHolder> {

    private final ArrayList<StudentModal> studentModalArrayList;
    private final Context context;

    public StudentViewer(ArrayList<StudentModal> studentModalArrayList, Context context) {
        this.studentModalArrayList = studentModalArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_viewer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        StudentModal modal = studentModalArrayList.get(position);
        holder.studentIDTextView.setText("Student ID: " + modal.getStudentID());
        holder.firstNameTextView.setText("First Name: " + modal.getFirstName());
        holder.lastNameTextView.setText("Last Name: " + modal.getLastName());
        holder.gradeTextView.setText("Grade: " + modal.getGrade());

        holder.itemView.setOnClickListener(v -> {

            Intent i = new Intent(context, UpdateStudentActivity.class);

            i.putExtra("student ID", modal.getStudentID());
            i.putExtra("first name", modal.getFirstName());
            i.putExtra("last name", modal.getLastName());
            i.putExtra("grade", modal.getGrade());

            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return studentModalArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView studentIDTextView, firstNameTextView, lastNameTextView, gradeTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            studentIDTextView = itemView.findViewById(R.id.studentID);
            firstNameTextView = itemView.findViewById(R.id.firstName);
            lastNameTextView = itemView.findViewById(R.id.lastName);
            gradeTextView = itemView.findViewById(R.id.grade);
        }
    }
}
