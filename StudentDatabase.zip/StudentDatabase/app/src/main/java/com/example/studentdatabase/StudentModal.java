package com.example.studentdatabase;

public class StudentModal {
    private String studentID;
    private String grade;
    private String firstName;
    private String lastName;

    public String getStudentID() {
        return studentID;
    }
    public void setStudentID(String studentID) { this.studentID = studentID; }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGrade() {
        return grade;
    }
    public void setGrade(String grade) {
        this.grade = grade;
    }

    public StudentModal(String studentID, String firstName, String lastName, String grade) {
        this.studentID = studentID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.grade = grade;
    }
}
