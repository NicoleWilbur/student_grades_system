package com.example.studentdatabase;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UpdateStudentActivity extends AppCompatActivity {

    private EditText editStudentID, editFirstName, editLastName, editGrade;
    private DBHandler dbHandler;
    String studentID, firstName, lastName, grade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);

        editStudentID = findViewById(R.id.editStudentID);
        editFirstName = findViewById(R.id.editFirstName);
        editLastName = findViewById(R.id.editLastName);
        editGrade = findViewById(R.id.editGrade);
        Button updateButton = findViewById(R.id.updateButton);
        Button deleteButton = findViewById(R.id.deleteButton);

        dbHandler = new DBHandler(UpdateStudentActivity.this);

        studentID = getIntent().getStringExtra("student ID");
        firstName = getIntent().getStringExtra("first name");
        lastName = getIntent().getStringExtra("last name");
        grade = getIntent().getStringExtra("grade");

        editStudentID.setText(studentID);
        editFirstName.setText(firstName);
        editLastName.setText(lastName);
        editGrade.setText(grade);

        updateButton.setOnClickListener(v -> {
            try {
                String tempStudentID = editStudentID.getText().toString();

                if (tempStudentID.isEmpty()) {
                    Toast.makeText(UpdateStudentActivity.this, "Student ID is Mandatory",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
              /***  if (!dbHandler.checkStudentID(studentID)){
                    Toast.makeText(UpdateStudentActivity.this, "Student ID is a Duplicate",
                            Toast.LENGTH_SHORT).show();
                }***/
                dbHandler.updateStudent(studentID, tempStudentID,
                        editFirstName.getText().toString(), editLastName.getText().toString(),
                        editGrade.getText().toString());

                Toast.makeText(UpdateStudentActivity.this, "Student Record Updated",
                        Toast.LENGTH_SHORT).show();

                Intent i = new Intent(UpdateStudentActivity.this, MainActivity.class);
                startActivity(i);
            }
            catch (Exception e){
                Toast.makeText(UpdateStudentActivity.this, "Something went wrong; " +
                                "ensure you are not adding a duplicate record and try again.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
        });

        deleteButton.setOnClickListener(v -> {
            try {
                dbHandler.deleteStudent(studentID);
                Toast.makeText(UpdateStudentActivity.this, "Student Record Deleted",
                        Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateStudentActivity.this, MainActivity.class);
                startActivity(i);
            }
            catch (Exception e){
                Toast.makeText(UpdateStudentActivity.this, "Something went wrong; try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
