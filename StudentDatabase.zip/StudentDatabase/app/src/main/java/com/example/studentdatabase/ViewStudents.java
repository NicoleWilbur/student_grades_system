package com.example.studentdatabase;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewStudents extends AppCompatActivity {

    private ArrayList<StudentModal> studentModalArrayList;
    private DBHandler dbHandler;
    private StudentViewer studentViewer;
    private RecyclerView studentRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_students);

        studentModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ViewStudents.this);

        studentModalArrayList = dbHandler.viewStudents();

        studentViewer = new StudentViewer(studentModalArrayList, ViewStudents.this);
        studentRV = findViewById(R.id.StudentRV);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager
                (ViewStudents.this, RecyclerView.VERTICAL, false);
        studentRV.setLayoutManager(linearLayoutManager);

        studentRV.setAdapter(studentViewer);
    }
}
