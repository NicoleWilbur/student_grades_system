package com.example.studentdatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "student_grades_db";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "student_records";
    private static final String STUDENT_ID_COL = "student_id";
    private static final String FIRST_NAME_COL = "first_name";
    private static final String LAST_NAME_COL = "last_name";
    private static final String GRADE_COL = "grade";

    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + STUDENT_ID_COL + " TEXT PRIMARY KEY,"
                + FIRST_NAME_COL + " TEXT,"
                + LAST_NAME_COL + " TEXT,"
                + GRADE_COL + " TEXT)";
        db.execSQL(query);
    }

    public void addNewStudent(String studentID, String firstName, String lastName, String grade) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(STUDENT_ID_COL, studentID);
        values.put(FIRST_NAME_COL, firstName);
        values.put(LAST_NAME_COL, lastName);
        values.put(GRADE_COL, grade);

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ArrayList<StudentModal> viewStudents() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorStudents = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        ArrayList<StudentModal> studentModalArrayList = new ArrayList<>();

        if (cursorStudents.moveToFirst()) {
            do {
                studentModalArrayList.add(new StudentModal(cursorStudents.getString(0),
                        cursorStudents.getString(1),
                        cursorStudents.getString(2),
                        cursorStudents.getString(3)));
            } while (cursorStudents.moveToNext());
        }
        cursorStudents.close();
        return studentModalArrayList;
    }

    public void updateStudent(String originalStudentID, String studentID, String firstName,
                             String lastName, String grade) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(STUDENT_ID_COL, studentID);
        values.put(FIRST_NAME_COL, firstName);
        values.put(LAST_NAME_COL, lastName);
        values.put(GRADE_COL, grade);

        db.update(TABLE_NAME, values, "student_id=?", new String[]{originalStudentID});
        db.close();
    }

    public void deleteStudent(String studentID) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, "student_id=?", new String[]{studentID});
        db.close();
    }

    public boolean checkStudentID (String studentID) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor checkID = db.rawQuery("SELECT student_id FROM " + TABLE_NAME +
                " where student_id=?", new String[]{studentID});
        String x = checkID.getString(0);
        checkID.close();
        if (x == null || x.isEmpty()) {
            return false;
        }
        else {
            return true;
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}

